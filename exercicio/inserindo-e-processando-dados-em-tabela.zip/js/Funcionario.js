import Pessoa from "./Pessoa.js";

export default class Funcionario extends Pessoa{

    novaPessoa() {
        super.novaPessoa();
    }

}